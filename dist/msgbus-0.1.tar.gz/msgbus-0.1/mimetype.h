/* $Id: mimetype.h 4 2006-12-08 19:12:25Z dugsong $ */

#ifndef MIMETYPE_H
#define MIMETYPE_H

void		 mimetype_load(const char *path);
const char	*mimetype_guess(const char *path);

#endif /* MIMETYPE_H */
